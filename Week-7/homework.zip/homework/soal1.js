const rumus = require("./module");
const panjangSisiPersegi = 5;
const panjangPersegiPanjang = 10;
const lebarPersegiPanjang = 15;

rumus.luasPersegi(panjangSisiPersegi);
rumus.kelilingPersegi(panjangSisiPersegi);
rumus.luasPersegiPanjang(panjangPersegiPanjang, lebarPersegiPanjang);
rumus.kelilingPersegiPanjang(panjangPersegiPanjang, lebarPersegiPanjang);
